import { Router } from "express";

const router = Router();

// Esta rota estava com erro e não existe no controller,
// portanto será removida por completo.

export default router;
